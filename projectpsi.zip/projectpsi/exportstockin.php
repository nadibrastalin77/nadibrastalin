<?php
// Memulai koneksi ke database
require "function.php";  // Pastikan koneksi database ada di sini

// Ambil data dari database
$ambilsemuadatastock = mysqli_query($conn, "SELECT idmasuk, machine, namapart, partnumber, tanggal, pic, qty, uom 
    FROM masuk
    JOIN stock s ON s.partnumber = m.partnumber");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Export Stock In</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">
  <style> 
    .my-custom-table td {
        border-right: 1px solid #000;
    }
    .my-custom-table th {
        border-right: 1px solid #000;
    }
    .my-custom-table td:last-child, .my-custom-table th:last-child {
        border-right: none;
    }
    .center-text {
        text-align: center;
    }
  </style>
</head>
<body>
<div class="container">
    <h2 class="text-center">Stock In Sparepart Maintenance </h2>
    <div class="data-tables datatable-dark">
        <a href="masuk.php" class="btn btn-info">Kembali</a>
        <br><br>
        <table class="table table-bordered my-custom-table" id="exportbarangmasuk" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th class="center-text">ID Masuk</th>
                    <th class="center-text">Machine</th>
                    <th class="center-text">Nama Part</th>
                    <th class="center-text">Part Number</th>
                    <th class="center-text">Tanggal</th>
                    <th class="center-text">PIC</th>
                    <th class="center-text">Qty</th>
                    <th class="center-text">UOM</th>
                </tr>
            </thead>
            <tbody>
            <?php
            // Menyesuaikan query dengan kolom yang ada di masuk.php
            $ambilsemuadatastock = mysqli_query($conn, "SELECT m.idmasuk, m.machine, m.namapart, m.partnumber, m.tanggal, m.pic, m.qty, m.uom 
                FROM masuk m 
                JOIN stock s ON s.partnumber = m.partnumber");
            while($data=mysqli_fetch_array($ambilsemuadatastock)){
                $idm = $data['idmasuk'];
                $machine = $data['machine'];
                $namabarang = $data['namapart'];
                $partnumber = $data['partnumber'];
                $tanggal = $data['tanggal']; 
                $qty = $data['qty'];
                $pic = $data['pic'];
                $uom = $data['uom'];
            ?>
            <tr>
                <td class="center-text"><?php echo $idm;?></td>
                <td class="center-text"><?php echo $machine;?></td>
                <td class="center-text"><?php echo $namabarang;?></td>
                <td class="center-text"><?php echo $partnumber;?></td>
                <td class="center-text"><?php echo $tanggal;?></td>
                <td class="center-text"><?php echo $pic;?></td>
                <td class="center-text"><?php echo $qty;?></td>
                <td class="center-text"><?php echo $uom;?></td>
            </tr>
            <?php
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.print.min.js"></script>

<script>
$(document).ready(function() {
    $('#exportbarangmasuk').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'excel', 
            {
                extend: 'pdf',
                title: 'Stock In Sparepart Maintenance',
                customize: function (doc) {
                    doc.styles.tableHeader.color = '#000';
                    doc.content[1].table.body.forEach(function(row) {
                        row.forEach(function(cell) {
                            cell.color = '#000';
                            cell.fillColor = '#FFF';
                            cell._border = ['T', 'B', 'L', 'R'];
                        });
                    });
                }
            }, 
            {
                extend: 'print',
                title: 'Stock In Sparepart Maintenance',
                customize: function (win) {
                    $(win.document.body).find('h1').css('text-align', 'center');
                }
            }
        ],
        pageLength: 50
    });
});
</script>
</body>
</html>
