<?php
session_start();
require_once "function.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <!-- Navbar -->
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <h1 class="navbar-brand ps-3">Inventory Management System</h1>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!">
            <i class="fas fa-bars"></i>
        </button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <!-- Sidebar Navigation -->
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock
                        </a>
                        <a class="nav-link" href="masuk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock In
                        </a>
                        <a class="nav-link" href="keluar.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock Out
                        </a>
                        <a class="nav-link" href="supplier.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Supplier
                        </a>
                        <a class="nav-link" href="ivr.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            IVR
                        </a>
                        <a class="nav-link" href="logout.php">Logout</a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="Big">Maintenance Team</div>
                    R-975
                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Inventory Variance Record Sparepart</h1>
                    <div class="card mb-4">
                    <div class="card-header">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                            Tambah Data Variance
                        </button>
                        <a href="exportivr.php" class="btn btn-info">Export Data Variance</a>
                    </div>
                        <div class="card-body">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Opname Date</th>
                                        <th>Part Number</th>
                                        <th>Nama Part</th>
                                        <th>System Quantity</th>
                                        <th>Actual Quantity</th>
                                        <th>Difference</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $ambilsemuadatastock = mysqli_query($conn, "SELECT i.idivr, i.tanggal_opname, i.partnumber, i.namapart, i.systemqty, i.actualqty, i.difference, s.idbarang
                                    FROM ivr i 
                                    JOIN stock s ON s.partnumber = i.partnumber ");
                                    while ($data = mysqli_fetch_array($ambilsemuadatastock)) {
                                        $idbarang = $data['idbarang'];
                                        $idivr = $data['idivr'];
                                        $tanggal_opname = $data['tanggal_opname'];
                                        $partnumber = $data['partnumber'];
                                        $namapart = $data['namapart'];
                                        $systemqty = $data['systemqty'];
                                        $actualqty = $data['actualqty'];
                                        $difference = $data['difference'];
                                    ?>
                                        <tr>
                                            <td><?= $idivr; ?></td>
                                            <td><?= $tanggal_opname; ?></td>
                                            <td><?= $partnumber; ?></td>
                                            <td><?= $namapart; ?></td>
                                            <td><?= $systemqty; ?></td>
                                            <td><?= $actualqty; ?></td>
                                            <td><?= $difference; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $idivr; ?>">
                                                    Edit
                                                </button>
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete<?= $idivr; ?>">
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>

                                        <!-- Edit The Modal -->
                                        <div class="modal fade" id="edit<?= $idivr; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Edit Stock</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            <input type="text" name="tanggalopname" value="<?= $tanggalopname; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="partnumber" value="<?= $partnumber; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="namapart" value="<?= $namapart; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="number" name="systemqty" value="<?= $systemqty; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="actualqty" value="<?= $actualqty; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="number" name="difference" value="<?= $difference; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="hidden" name="idivr" value="<?= $idivr; ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" name="updatebarang" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Delete The Modal -->
                                        <div class="modal fade" id="delete<?= $idivr; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Hapus Stock</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            Apakah anda yakin ingin menghapus stock <?= $namapart; ?>?
                                                            <input type="hidden" name="idbarang" value="<?= htmlspecialchars($idbarang); ?>">
                                                            <input type="hidden" name="idivr" value="<?= htmlspecialchars($idivr); ?>">
                                                            <input type="hidden" name="difference" value="<?= htmlspecialchars($difference); ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" name="hapusivr" class="btn btn-danger">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>

<div class="modal fade" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Tambah IVR</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <!-- Modal Tambah Barang -->
                    <form method="post">
                        <div class="modal-body">
                            <select name="idbarang" id="idbarang" class="form-control" required onchange="fillPartDetails()">
                                <?php
                                $ambilsemuadata = mysqli_query($conn, "SELECT * FROM stock");
                                while ($fetcharray = mysqli_fetch_array($ambilsemuadata)) {
                                    $partnumber = $fetcharray['partnumber'];
                                    $namabarang = $fetcharray['namapart'];
                                    $idbarang =  $fetcharray['idbarang'];
                                    $qty = $fetcharray['qty'];
                                ?>
                                    <option value="<?= $idbarang; ?>" 
                                            data-partnumber="<?= $partnumber; ?>" 
                                            data-namapart="<?= $namabarang; ?>"
                                            data-qty="<?= $qty; ?>">
                                            <?= $partnumber; ?> - <?= $namabarang; ?>
                                    </option> 
                                <?php
                                }
                                ?>
                            </select>
                            <br>
                            <input type="date" id="tanggal_opname" name="tanggal_opname" placeholder="Tanggal" class="form-control" required>
                            <br>
                            <input type="text" id="namapart" name="namapart" placeholder="Nama Part" class="form-control" required>
                            <br>
                            <input type="text" id="partnumber" name="partnumber" placeholder="Part Number" class="form-control" required>
                            <br>
                            <input type="number" id="qty" name="systemqty" placeholder="System Quantity" class="form-control" required>
                            <br>
                            <input type="number" name="actualqty" placeholder="Actual Quantity" class="form-control" required>
                            <br>
                            <input type="number" name="difference" placeholder="Difference" class="form-control" disabled>
                            <br>
                            <button type="submit" class="btn btn-primary" name="ivr">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    <script>
    function fillPartDetails() {
        var select = document.getElementById("idbarang");
        var selectedOption = select.options[select.selectedIndex];
        document.getElementById("namapart").value = selectedOption.getAttribute("data-namapart");
        document.getElementById("partnumber").value = selectedOption.getAttribute("data-partnumber");
        document.getElementById("qty").value = selectedOption.getAttribute("data-qty");
    }
    </script>
</html>
