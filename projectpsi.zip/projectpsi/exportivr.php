<?php
// Memulai koneksi ke database
require "function.php";  // Pastikan koneksi database ada di sini

// Ambil data dari database
$ambilsemuadatastock = mysqli_query($conn, "SELECT * FROM ivr ");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Export Stock Out</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">
    <style>
        .my-custom-table td {
            border-right: 1px solid #000;
        }

        .my-custom-table th {
            border-right: 1px solid #000;
        }

        .my-custom-table td:last-child,
        .my-custom-table th:last-child {
            border-right: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center">Inventory Variance Stock Maintanance</h2>
        <a href="ivr.php" class="btn btn-info">Kembali</a>
        <br><br>
        <table class="table table-bordered my-custom-table" id="exportivr" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th class="center-text">No</th>
                    <th class="center-text">Opname Date</th>
                    <th class="center-text">Part Number</th>
                    <th class="center-text">Nama Part</th>
                    <th class="center-text">System Quantity</th>
                    <th class="center-text">Actual Quantity</th>
                    <th class="center-text">Difference</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Ambil data dari database dengan join antara tabel keluar dan stock
                $ambilsemuadatastock = mysqli_query($conn, "SELECT  * FROM ivr");
                while($data=mysqli_fetch_array($ambilsemuadatastock)){
                    $idivr = $data['idivr'];
                    $tanggal_opname = $data['tanggal_opname'];
                    $namabarang = $data['namapart'];
                    $partnumber = $data['partnumber'];
                    $systemqty = $data['systemqty']; 
                    $actualqty = $data['actualqty'];
                    $difference = $data['difference'];
                ?>
                <tr>
                    <td class="center-text"><?php echo $idivr;?></td>
                    <td class="center-text"><?php echo $tanggal_opname;?></td>
                    <td class="center-text"><?php echo $namabarang;?></td>
                    <td class="center-text"><?php echo $partnumber;?></td>
                    <td class="center-text"><?php echo $systemqty;?></td>
                    <td class="center-text"><?php echo $actualqty;?></td>
                    <td class="center-text"><?php echo $difference;?></td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.print.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#exportivr').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'excel',
                    {
                        extend: 'pdf',
                        title: 'Inventory Variance Stock Maintenance',
                        customize: function(doc) {
                            doc.styles.tableHeader.color = '#000';
                            doc.content[1].table.body.forEach(function(row) {
                                row.forEach(function(cell) {
                                    cell.color = '#000';
                                    cell.fillColor = '#FFF';
                                    cell._border = ['T', 'B', 'L', 'R'];
                                });
                            });
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Inventory Variance Stock Maintenance',
                        customize: function(win) {
                            $(win.document.body).find('h1').css('text-align', 'center');
                        }
                    }
                ],
                pageLength: 50
            });
        });
    </script>
</body>

</html>