<?php
$servername = "localhost";
$username = "bramleo19";
$password = "";
$dbname = "r975kp";
session_start();

// Koneksi ke database
$conn = mysqli_connect("localhost", "bramleo19", "", "r975kp");

// Fungsi untuk mengirim notifikasi WhatsApp
function sendWhatsAppNotification($nik, $conn)
{
    // API Endpoint dan Key (contoh menggunakan Twilio API)
    $twilio_sid = 'ACa71a5542f7da2f95bc043a4282ff590e';
    $twilio_token = '7473d80e59d8015a291d59a6031cdfc3';
    $twilio_whatsapp_number = 'whatsapp:+14155238886';

    // Dapatkan nomor WhatsApp pengguna berdasarkan NIK
    $query = mysqli_query($conn, "SELECT phone_number FROM users WHERE nik = '$nik'");
    $user = mysqli_fetch_assoc($query);

    if ($user && $user['phone_number']) {
        $recipient_number = 'whatsapp:' . $user['phone_number']; // Nomor WhatsApp pengguna yang terdaftar
        $message = "User dengan NIK $nik baru saja login.";

        // Menggunakan cURL untuk mengirim pesan melalui Twilio
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.twilio.com/2010-04-01/Accounts/$twilio_sid/Messages.json");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'From' => $twilio_whatsapp_number,
            'To' => $recipient_number,
            'Body' => $message
        ]));
        curl_setopt($ch, CURLOPT_USERPWD, "$twilio_sid:$twilio_token");

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
    } else {
        echo "Nomor WhatsApp tidak ditemukan untuk NIK: $nik";
    }
}


// Tambah stok barang ke database
if (isset($_POST['stock'])) {
    $machine = $_POST['machine'];
    $partnumber = $_POST['partnumber'];
    $namapart = $_POST['namapart'];
    $qty = $_POST['qty'];
    $uom = $_POST['uom'];
    $supplier = $_POST['supplier'];

    $addtotable = mysqli_query($conn, "INSERT INTO stock (machine, partnumber, namapart, qty, uom, supplier) VALUES ('$machine', '$partnumber', '$namapart', '$qty', '$uom', '$supplier')");
    if ($addtotable) {
        header('location: index.php');
    } else {
        echo 'Gagal';
        header('location: index.php');
    }
}

// Tambah barang masuk
if (isset($_POST['barangmasuk'])) {
    $barangani = $_POST['idbarang'];
    $machine = $_POST['machine'];
    $namapart = $_POST['namapart'];
    $partnumber = $_POST['partnumber'];
    $uom = $_POST['uom'];
    $pic = $_POST['pic'];
    $qty = $_POST['qty'];

    // Ambil data stock saat ini
    $cekstocksekarang = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$barangani'");
    $ambildatanya = mysqli_fetch_array($cekstocksekarang);
    $stocksekarang = $ambildatanya['qty']; // Perhatikan kolom yang sesuai

    // Tambahkan stok saat ini dengan quantity
    $tambahkanstocksekarangdenganquantity = $stocksekarang + $qty;

    // Masukkan data ke tabel masuk
    $addtomasuk = mysqli_query($conn, "INSERT INTO masuk (idbarang, machine, namapart, partnumber, tanggal, pic, qty, uom) 
        VALUES ('$barangani', '$machine', '$namapart', '$partnumber', CURRENT_TIMESTAMP, '$pic', '$qty', '$uom')");

    // Perbarui stock di tabel stock
    $updatestockmasuk = mysqli_query($conn, "UPDATE stock SET qty='$tambahkanstocksekarangdenganquantity' WHERE idbarang='$barangani'");

    if ($addtomasuk && $updatestockmasuk) {
        header('location: masuk.php');
    } else {
        echo 'Gagal';
        header('location: masuk.php');
    }
}

if (isset($_POST['updatebarang'])) {
    $idbarang = $_POST['idbarang'];
    $machine = $_POST['machine'];
    $partnumber = $_POST['partnumber'];
    $namapart = $_POST['namapart'];
    $qty = $_POST['qty'];
    $uom = $_POST['uom'];
    $supplier = $_POST['supplier'];

    $update = mysqli_query($conn, "update stock set machine='$machine', partnumber='$partnumber', qty='$qty', uom='$uom', supplier='$supplier' where idbarang ='$idbarang'");
    if($update){
        header('location:dashboard.php');
    } else {
        echo 'Gagal';
    }
}

// Hapus barang dari stock
if (isset($_POST['hapusbarang'])) {
    $idbarang = $_POST['idbarang'];
    $hapus = mysqli_query($conn, "DELETE FROM stock WHERE idbarang='$idbarang'");
    if ($hapus) {
        header('location: dashboard.php');
    } else {
        echo 'Gagal';
        header('location: dashboard.php');
    }
}

// Ubah data barang masuk
if (isset($_POST['updatebarangmasuk'])) {
    $idb = $_POST['idb'];
    $idm = $_POST['idm'];
    $qty = $_POST['qty'];
    $pic = $_POST['pic'];
    $uom = $_POST['uom'];

    // Ambil data stock saat ini
    $lihatstock = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$idb'");
    $stocknya = mysqli_fetch_array($lihatstock);
    $stocksekarang = $stocknya['qty']; // Menggunakan kolom 'qty' dari tabel stock

    // Ambil qty lama dari tabel masuk
    $qtysekarang = mysqli_query($conn, "SELECT * FROM masuk WHERE idmasuk='$idm'");
    $qtynya = mysqli_fetch_array($qtysekarang);
    $qtylama = $qtynya['qty'];

    // Hitung perbedaan qty
    $diff_qty = $qty - $qtylama;
    // Sesuaikan stok dengan perbedaan qty
    $stockbaru = $stocksekarang + $diff_qty;

    // Update stok dan data barang masuk
    $updatestocknya = mysqli_query($conn, "UPDATE stock SET qty='$stockbaru' WHERE idbarang='$idb'");
    $updatestock = mysqli_query($conn, "UPDATE masuk SET qty='$qty', pic='$pic', uom='$uom' WHERE idmasuk='$idm'");

    if ($updatestocknya && $updatestock) {
        header('Location: masuk.php');
        exit();
    } else {
        echo 'Gagal';
        header('Location: masuk.php');
        exit();
    }
}


// Menghapus barang masuk
if (isset($_POST['hapusbarangmasuk'])) {
    $idb = $_POST['idb'];
    $idm = $_POST['idm'];
    $qty = $_POST['qty'];

    // Ambil data stok saat ini
    $getdatastock = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$idb'");
    $data = mysqli_fetch_array($getdatastock);
    $stock = $data['qty']; // Pastikan kolom yang benar digunakan

    // Hitung stok yang tersisa setelah penghapusan
    $selisih = $stock - $qty;

    // Update stok di tabel stock
    $update = mysqli_query($conn, "UPDATE stock SET qty='$selisih' WHERE idbarang='$idb'");

    // Hapus data dari tabel masuk
    $hapusdata = mysqli_query($conn, "DELETE FROM masuk WHERE idmasuk='$idm'");

    if ($update && $hapusdata) {
        header('Location: masuk.php');
        exit();
    } else {
        echo 'Gagal';
        header('Location: masuk.php');
        exit();
    }
}

// tambah barang keluar
if (isset($_POST['barangkeluar'])) {
    $idbarang = $_POST['idbarang'];
    $machine = $_POST['machine'];
    $namapart = $_POST['namapart'];
    $partnumber = $_POST['partnumber'];
    $uom = $_POST['uom'];
    $qty = $_POST['qty'];
    $pic = $_POST['pic'];

    // Ambil data stok saat ini
    $lihatstock = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$idbarang'");
    $stocknya = mysqli_fetch_array($lihatstock);
    $stocksekarang = $stocknya['qty'];

    // Kurangi stok dengan jumlah yang keluar
    $stockbaru = $stocksekarang - $qty;

    if ($stockbaru < 0) {
        echo 'Stok tidak mencukupi';
        header('location: keluar.php');
    } else {
        // Update stok di tabel stock
        $updatestock = mysqli_query($conn, "UPDATE stock SET qty='$stockbaru' WHERE idbarang='$idbarang'");
        // Masukkan data ke tabel keluar
        $addtokeluar = mysqli_query($conn, "INSERT INTO keluar (idbarang, machine, namapart, partnumber, uom, qty, pic) VALUES ('$idbarang', '$machine', '$namapart', '$partnumber', '$uom', '$qty', '$pic')");

        if ($updatestock && $addtokeluar) {
            header('location: keluar.php');
        } else {
            echo 'Gagal menambahkan data';
            header('location: keluar.php');
        }
    }
}

// Ubah data barang keluar
if (isset($_POST['updatebarangkeluar'])) {
    $idb = $_POST['idb'];
    $idk = $_POST['idk'];
    $namabarang = $_POST['namabarang'];
    $qty = $_POST['qty'];
    $pic = $_POST['pic'];
    $uom = $_POST['uom'];

    $lihatstock = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$idb'");
    $stocknya = mysqli_fetch_array($lihatstock);
    $stocksekarang = $stocknya['qty'];

    $qtysekarang = mysqli_query($conn, "SELECT * FROM keluar WHERE idkeluar='$idk'");
    $qtynya = mysqli_fetch_array($qtysekarang);
    $qtysekarang = $qtynya['qty'];

    // Hitung perbedaan qty
    $diff_qty = $qty - $qtysekarang;
    // Sesuaikan stok dengan perbedaan qty
    $stockbaru = $stocksekarang - $diff_qty;

    $updatestocknya = mysqli_query($conn, "UPDATE stock SET qty='$stockbaru' WHERE idbarang='$idb'");
    $updatestock = mysqli_query($conn, "UPDATE keluar SET qty='$qty', pic='$pic', uom='$uom' WHERE idkeluar='$idk'");
    if ($updatestocknya && $updatestock) {
        header('location: keluar.php');
    } else {
        echo 'Gagal';
        header('location: keluar.php');
    }
}

// Menghapus barang keluar
if (isset($_POST['hapusbarangkeluar'])) {
    $idb = $_POST['idb'];
    $idk = $_POST['idk'];
    $qty = $_POST['qty'];

    // Ambil data stok dari tabel stock
    $getdatastock = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$idb'");
    $data = mysqli_fetch_array($getdatastock);
    $stock = $data['qty']; // Menggunakan kolom 'qty' sesuai dengan struktur tabel

    // Hitung selisih stok
    $selisih = $stock + $qty; // Mengembalikan qty yang dihapus ke stok

    // Update stok di tabel stock
    $update = mysqli_query($conn, "UPDATE stock SET qty='$selisih' WHERE idbarang='$idb'");

    // Hapus data dari tabel keluar
    $hapusdata = mysqli_query($conn, "DELETE FROM keluar WHERE idkeluar='$idk'");

    if ($update && $hapusdata) {
        header('Location: keluar.php');
        exit();
    } else {
        echo 'Gagal';
        header('Location: keluar.php');
        exit();
    }
    //supplier
    if (isset($_POST['addsupplier'])) {
        $namasupplier = $_POST['namasupplier'];
        $email = $_POST['email'];
        $notelpon = $_POST['notelpon'];
        $pic = $_POST['pic'];

        $sql = "INSERT INTO supplier (namasupplier, email, notelpon, pic) VALUES ('$namasupplier', '$email', '$notelpon', '$pic')";
        if ($conn->query($sql) === TRUE) {
            header('Location: supplier.php');
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();

    if (isset($_POST['update_supplier'])) {
        $idsupplier = $_POST['idsupplier'];
        $namasupplier = $_POST['namasupplier'];
        $email = $_POST['email'];
        $notelpon = $_POST['notelpon'];
        $pic = $_POST['pic'];

        $query = "UPDATE supplier SET namasupplier='$namasupplier', email='$email', notelpon='$notelpon', pic='$pic' WHERE idsupplier='$idsupplier'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            header('Location: supplier.php');
        } else {
            echo "Gagal mengupdate data supplier.php";
        }
    }

    if (isset($_POST['hapus_supplier'])) {
        $idsupplier = $_POST['idsupplier'];

        $query = "DELETE FROM supplier WHERE idsupplier='$idsupplier'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            header('Location: supplier.php');
        } else {
            echo "Gagal menghapus data supplier.php";
        }
    }
}

// Tambah ivr
if (isset($_POST['ivr'])) {
    $idbarang = $_POST['idbarang'];
    $tanggal_opname = $_POST['tanggal_opname'];
    $namapart = $_POST['namapart'];
    $partnumber = $_POST['partnumber'];
    $systemqty = $_POST['systemqty'];
    $actualqty = $_POST['actualqty'];
    $difference = $actualqty - $systemqty;

    // Ambil data stock saat ini
    $cekstocksekarang = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$idbarang'");
    $ambildatanya = mysqli_fetch_array($cekstocksekarang);
    $stocksekarang = $ambildatanya['qty']; // Perhatikan kolom yang sesuai

    if ($difference > 0) {
        // Jika actualqty lebih besar dari systemqty, tambahkan stok
        $newstock = $stocksekarang + $difference;
    } else {
        // Jika actualqty lebih kecil dari systemqty, kurangi stok
        $newstock = $stocksekarang + $difference; // difference akan negatif, jadi akan mengurangi stok
    }


    // Masukkan data ke tabel masuk
    $addtoivr = mysqli_query($conn, "INSERT INTO ivr (idbarang, tanggal_opname, partnumber, namapart, systemqty, actualqty, difference) 
        VALUES ('$idbarang', '$tanggal_opname', '$partnumber', '$namapart', '$systemqty', '$actualqty', '$difference')");

    // Perbarui stock di tabel stock
    $updatestock = mysqli_query($conn, "UPDATE stock SET qty='$newstock' WHERE idbarang='$idbarang'");

    if ($addtoivr && $updatestock) {
        header('location: ivr.php');
    } else {
        echo 'Gagal';
    }
}

if (isset($_POST['hapusivr'])) {
    $idbarang = $_POST['idbarang'];
    $idivr = $_POST['idivr'];
    $difference = $_POST['difference'];

    // Ambil data stok saat ini
    $getdatastock = mysqli_query($conn, "SELECT * FROM stock WHERE idbarang='$idbarang'");
    $data = mysqli_fetch_array($getdatastock);
    $stock = $data['qty']; // Pastikan kolom yang benar digunakan

    // Hitung stok yang tersisa setelah penghapusan
    $selisih = $stock - $difference;

    // Update stok di tabel stock
    $update = mysqli_query($conn, "UPDATE stock SET qty='$selisih' WHERE idbarang='$idbarang'");

    // Hapus data dari tabel masuk
    $hapusdata = mysqli_query($conn, "DELETE FROM ivr WHERE idivr='$idivr'");

    if ($update && $hapusdata) {
        header('Location: ivr.php');
        exit();
    } else {
        echo 'Gagal';
    }
}