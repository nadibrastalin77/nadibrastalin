<?php
require "function.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, sans-serif;
        }
    </style>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script> -->
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <h1 a class="navbar-brand ps-3" href="index.php">Inventory Management System</h1>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock
                        </a>
                        <a class="nav-link" href="masuk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock In
                        </a>
                        <a class="nav-link" href="keluar.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock Out
                        </a>
                        <a class="nav-link" href="supplier.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Supplier
                        </a>
                        <a class="nav-link" href="ivr.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            IVR
                        </a>
                        <a class="nav-link" href="logout.php">
                            Logout
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="Big">Maintenance Team</div>
                    R-975
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Stock Out Sparepart</h1>
                    <div class="card mb-4">
                        <div class="card-header">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                                Tambah Stock Out
                            </button>
                            <a href="exportstockout.php" class="btn btn-info">Export Stock Out</a>

                        </div>
                        <div class="card-body">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Machine</th>
                                        <th>Nama Part</th>
                                        <th>Part Number</th>
                                        <th>Tanggal</th>
                                        <th>PIC</th>
                                        <th>Qty</th>
                                        <th>UOM</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $ambilsemuadatastock = mysqli_query($conn, "
                                    SELECT k.idkeluar, k.tanggal, k.partnumber, k.namapart, k.qty, k.pic, k.machine, k.uom, s.idbarang
                                    FROM keluar k
                                    JOIN stock s ON s.partnumber = k.partnumber");
                                    while ($data = mysqli_fetch_array($ambilsemuadatastock)) {
                                        $idb = $data['idbarang'];
                                        $idk = $data['idkeluar'];
                                        $tanggal = $data['tanggal'];
                                        $partnumber = $data['partnumber'];
                                        $namabarang = $data['namapart'];
                                        $qty = $data['qty'];
                                        $pic = $data['pic'];
                                        $machine = $data['machine'];
                                        $uom = $data['uom'];
                                    ?>
                                        <tr>
                                            <td><?= $idk; ?></td>
                                            <td><?= $machine; ?></td>
                                            <td><?= $namabarang; ?></td>
                                            <td><?= $partnumber; ?></td>
                                            <td><?= $tanggal; ?></td>
                                            <td><?= $pic; ?></td>
                                            <td><?= $qty; ?></td>
                                            <td><?= $uom; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $idk; ?>">
                                                    Edit
                                                </button>
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete<?= $idk; ?>">
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                        <!-- Edit The Modal -->
                                        <div class="modal fade" id="edit<?= $idk; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">

                                                    <!-- Modal Header -->
                                                    <div class="modal-header">

                                                        <h4 class="modal-title">Edit Stock Out</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            <input type="text" name="partnumber" value="<?= $partnumber; ?>" class="form-control" disabled>
                                                            <br>
                                                            <input type="text" name="namabarang" value="<?= $namabarang; ?>" class="form-control" disabled>
                                                            <br>
                                                            <input type="text" name="qty" value="<?= $qty; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="pic" value="<?= $pic; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="uom" value="<?= $uom; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="hidden" name="idb" value="<?= $idb; ?>">
                                                            <input type="hidden" name="idk" value="<?= $idk; ?>">
                                                            <button type="submit" class="btn btn-primary" name="updatebarangkeluar">Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Delete The Modal -->
                                        <div class="modal fade" id="delete<?= $idk; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">

                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Hapus Barang</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <form method="post" action="function.php">
                                                        <div class="modal-body">
                                                            Yakin ingin menghapus <?= htmlspecialchars($namabarang); ?>? Pastikan sekali lagi !!
                                                            <input type="hidden" name="idb" value="<?= htmlspecialchars($idb); ?>">
                                                            <input type="hidden" name="idk" value="<?= htmlspecialchars($idk); ?>">
                                                            <input type="hidden" name="qty" value="<?= htmlspecialchars($qty); ?>">
                                                            <br>
                                                            <br>
                                                            <button type="submit" class="btn btn-danger" name="hapusbarangkeluar">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>


                                    <?php
                                    };
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; PT.Sarimelati Kencana R-975 Factory Cikarang</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>
<!-- The Modal -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Tambah Stock Out</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <form method="post">
                <div class="modal-body">
                    <select name="idbarang" id="idbarang" class="form-control" required onchange="fillPartDetails()">
                        <?php
                        $ambilsemuadata = mysqli_query($conn, "SELECT * FROM stock");
                        while ($fetcharray = mysqli_fetch_array($ambilsemuadata)) {
                            $machine = $fetcharray['machine'];
                            $partnumberani = $fetcharray['partnumber'];
                            $namabarangani = $fetcharray['namapart'];
                            $idbarangani =  $fetcharray['idbarang'];
                        ?>
                            <option value="<?= $idbarangani; ?>" 
                                    data-machine="<?= $machine; ?>"
                                    data-partnumber="<?= $partnumberani; ?>" 
                                    data-namapart="<?= $namabarangani; ?>">
                                    <?= $machine; ?> - <?= $partnumberani; ?> - <?= $namabarangani; ?>
                            </option>
                        <?php
                        }
                        ?>
                    </select>
                    <br>
                    <input type="text" id="machine" name="machine" placeholder="Machine" class="form-control" required>
                    <br>
                    <input type="text" id="namapart" name="namapart" placeholder="Nama Part" class="form-control" required>
                    <br>
                    <input type="text" id="partnumber" name="partnumber" placeholder="Part Number" class="form-control" required>
                    <br>
                    <input type="text" name="uom" placeholder="UOM" class="form-control" required>
                    <br>
                    <input type="number" name="qty" placeholder="Quantity" class="form-control" required>
                    <br>
                    <input type="text" name="pic" placeholder="PIC" class="form-control" required>
                    <br>
                    <button type="submit" class="btn btn-primary" name="barangkeluar">Submit</button>
                </div>
            </form>

        </div>
    </div>
</div>

<script>
function fillPartDetails() {
    var select = document.getElementById("idbarang");
    var selectedOption = select.options[select.selectedIndex];
    document.getElementById("machine").value = selectedOption.getAttribute("data-machine");
    document.getElementById("namapart").value = selectedOption.getAttribute("data-namapart");
    document.getElementById("partnumber").value = selectedOption.getAttribute("data-partnumber");
}
</script>



</html>