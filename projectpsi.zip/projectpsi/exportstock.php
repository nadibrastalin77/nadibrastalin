<?php
require "function.php";
$ambilsemuadatastock = mysqli_query($conn, "SELECT idmasuk, machine, namapart, partnumber, tanggal, pic, qty, uom 
    FROM stock
    JOIN stock s ON s.partnumber = m.partnumber");
?>
<html>
<head>
    <title>R-975 Maintenance</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>

    <style>
        .my-custom-table td {
            border-right: 1px solid #000;
        }

        .my-custom-table th {
            border-right: 1px solid #000;
        }

        .my-custom-table td:last-child, .my-custom-table th:last-child {
            border-right: none;
        }
    </style>
</head>

<head>
    <style>
        .center-text {
            text-align: center;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 style="text-align: center;">Maintenance Stock Sparepart</h2>
    <div class="data-tables datatable-dark">
        <a href="dashboard.php" class="btn btn-info">Kembali</a>
        <br>
        <br>
        <table class="table table-bordered my-custom-table" id="exportstockbarangani" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th class="center-text">NO</th>
                    <th class="center-text">PART NUMBER</th>
                    <th class="center-text">NAMA PART</th>
                    <th class="center-text">MACHINE</th>
                    <th class="center-text">QUANTITY</th>
                    <th class="center-text">UOM</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $ambilsemuadatastock = mysqli_query($conn, "SELECT * FROM stock");
                $no = 1; // Mulai dari 1
                while ($data = mysqli_fetch_array($ambilsemuadatastock)) {
                    $partnumber = $data['partnumber'];
                    $namapart = $data['namapart'];
                    $machine = $data['machine'];
                    $qty = $data['qty'];
                    $uom = $data['uom'];
                    $idb = $data['idbarang'];
                ?>
                <tr>
                    <td class="center-text"><?= $no++; ?></td>
                    <td class="center-text"><?= $partnumber; ?></td>
                    <td class="center-text"><?= $namapart; ?></td>
                    <td class="center-text"><?= $machine; ?></td>
                    <td class="center-text"><?= $qty; ?></td>
                    <td class="center-text"><?= $uom; ?></td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<script>
$(document).ready(function() {
    $('#exportstockbarangani').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'excel', 
            {
                extend: 'pdf',
                title: 'Maintenance Stock Sparepart', // Tambahkan judul khusus untuk PDF
                customize: function (doc) {
                    // Ubah semua warna teks menjadi hitam
                    doc.styles.tableHeader.color = '#000';
                    doc.content[1].table.body.forEach(function(row) {
                        row.forEach(function(cell) {
                            cell.color = '#000';
                            cell.fillColor = '#FFF'; // Ubah warna latar belakang menjadi putih
                            cell._border = ['T', 'B', 'L', 'R']; // Tambahkan border di sekitar setiap sel
                        });
                    });
                }
            }, 
            {
                extend: 'print',
                title: 'Maintenance Stock Sparepart', // Tambahkan judul khusus untuk Print
                customize: function (win) {
                    $(win.document.body).find('h1').css('text-align', 'center');
                }
            }
        ],
        pageLength: 50
    });
});
</script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.print.min.js"></script>
</body>
</html>
