<?php
session_start();
require_once "function.php";

// Proses untuk menambahkan barang masuk
if (isset($_POST['barangmasuk'])) {
    $machine = $_POST['machine'];
    $partnumber = $_POST['partnumber'];
    $namapart = $_POST['namapart'];
    $qty = $_POST['qty'];
    $uom = $_POST['uom'];

    $query = "INSERT INTO stock (machine, partnumber, namapart, qty, uom) VALUES ('$machine', '$partnumber', '$namapart', '$qty', '$uom')";
    $result = mysqli_query($conn, $query);

    // Notifikasi hasil penambahan stock
    if ($result) {
        echo "<script>alert('Stock berhasil ditambahkan');</script>";
    } else {
        echo "<script>alert('Gagal menambahkan stock');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <!-- Navbar -->
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <h1 class="navbar-brand ps-3">Inventory Management System</h1>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!">
            <i class="fas fa-bars"></i>
        </button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <!-- Sidebar Navigation -->
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock
                        </a>
                        <a class="nav-link" href="masuk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock In
                        </a>
                        <a class="nav-link" href="keluar.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock Out
                        </a>
                        <a class="nav-link" href="supplier.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Supplier
                        </a>
                        <a class="nav-link" href="ivr.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            IVR
                        </a>
                        <a class="nav-link" href="logout.php">Logout</a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="Big">Maintenance Team</div>
                    R-975
                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Stock Sparepart</h1>
                    <div class="card mb-4">
                    <div class="card-header">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                            Tambah Barang
                        </button>
                        <a href="exportstock.php" class="btn btn-info">Export Data Stock</a>
                    </div>
                        <div class="card-body">
                            <table id="datatablesSimple">
                                <!-- Modal untuk Peringatan Stock -->
                                <div class="modal fade" id="stockAlertModal" tabindex="-1" aria-labelledby="stockAlertModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="stockAlertModalLabel">Peringatan Stock Sparepart Minim/Habis!</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <?php
                                                // Peringatan untuk stock < 2
                                                $ambildatastock = mysqli_query($conn, "SELECT * FROM stock WHERE qty < 2");
                                                $data_tersedia = false;

                                                while ($fetch = mysqli_fetch_array($ambildatastock)) {
                                                    $barang = $fetch['namapart'];
                                                    $data_tersedia = true;
                                                ?>
                                                    <div class="alert alert-warning alert-dismissible">
                                                        <strong>Peringatan!</strong> Stock sparepart <?= $barang; ?> Minim! Segera order ke supplier terkait!
                                                    </div>
                                                <?php
                                                }

                                                // Peringatan untuk stock < 1
                                                $ambildatastock = mysqli_query($conn, "SELECT * FROM stock WHERE qty < 1");
                                                while ($fetch = mysqli_fetch_array($ambildatastock)) {
                                                    $barang = $fetch['namapart'];
                                                    $data_tersedia = true;
                                                ?>
                                                    <div class="alert alert-danger alert-dismissible">
                                                        <strong>Peringatan!</strong> Stock sparepart <?= $barang; ?> Habis! Segera order ke supplier terkait!
                                                    </div>
                                                <?php
                                                }

                                                if (!$data_tersedia) {
                                                    echo "<p>Stock Sparepart ready guys aman.</p>";
                                                }
                                                ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Script untuk memunculkan modal secara otomatis -->
                                <script>
                                    document.addEventListener("DOMContentLoaded", function() {
                                        var modalElement = document.getElementById('stockAlertModal');
                                        var modal = new bootstrap.Modal(modalElement);
                                        modal.show();
                                    });
                                </script>

                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Machine</th>
                                        <th>Part Number</th>
                                        <th>Nama Part</th>
                                        <th>Quantity</th>
                                        <th>UOM</th>
                                        <th>Supplier</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $ambilsemuadatastock = mysqli_query($conn, "SELECT * FROM stock");
                                    while ($data = mysqli_fetch_array($ambilsemuadatastock)) {
                                        $idbarang = $data['idbarang'];
                                        $machine = $data['machine'];
                                        $partnumber = $data['partnumber'];
                                        $namapart = $data['namapart'];
                                        $qty = $data['qty'];
                                        $uom = $data['uom'];
                                        $supplier = $data['supplier'];
                                    ?>
                                        <tr>
                                            <td><?= $idbarang; ?></td>
                                            <td><?= $machine; ?></td>
                                            <td><?= $partnumber; ?></td>
                                            <td><?= $namapart; ?></td>
                                            <td><?= $qty; ?></td>
                                            <td><?= $uom; ?></td>
                                            <td><?= $supplier; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $idbarang; ?>">
                                                    Edit
                                                </button>
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete<?= $idbarang; ?>">
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>

                                        <!-- Edit The Modal -->
                                        <div class="modal fade" id="edit<?= $idbarang; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Edit Stock</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            <input type="text" name="machine" value="<?= $machine; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="partnumber" value="<?= $partnumber; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="namapart" value="<?= $namapart; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="number" name="qty" value="<?= $qty; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="uom" value="<?= $uom; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="supplier" value="<?= $supplier; ?>" class="form-control" required>
                                                            <br>
                                                            <input type="hidden" name="idbarang" value="<?= $idbarang; ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" name="updatebarang" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Delete The Modal -->
                                        <div class="modal fade" id="delete<?= $idbarang; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Hapus Stock</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            Apakah anda yakin ingin menghapus stock <?= $namapart; ?>?
                                                            <input type="hidden" name="idbarang" value="<?= $idbarang; ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" name="hapusbarang" class="btn btn-danger">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Modal Tambah Barang -->
            <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="myModalLabel">Tambah Barang</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="post">
                            <div class="modal-body">
                                <label>Machine</label>
                                <input type="text" name="machine" class="form-control" required>
                                <br>
                                <label>Part Number</label>
                                <input type="text" name="partnumber" class="form-control" required>
                                <br>
                                <label>Nama Part</label>
                                <input type="text" name="namapart" class="form-control" required>
                                <br>
                                <label>Quantity</label>
                                <input type="number" name="qty" class="form-control" required>
                                <br>
                                <label>UOM</label>
                                <input type="text" name="uom" class="form-control" required>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="barangmasuk" class="btn btn-primary">Tambah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>

</html>
