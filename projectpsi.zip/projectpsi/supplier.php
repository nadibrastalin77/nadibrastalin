<?php
require "function.php";

// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "r975kp");

// Cek koneksi
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Tangani form update
if (isset($_POST['update_supplier'])) {
    $idsupplier = $_POST['idsupplier'];
    $namasupplier = $_POST['namasupplier'];
    $email = $_POST['email'];
    $notelpon = $_POST['notelpon'];
    $pic = $_POST['pic'];

    $stmt = $conn->prepare("UPDATE supplier SET namasupplier=?, email=?, notelpon=?, pic=? WHERE idsupplier=?");
    $stmt->bind_param("ssssi", $namasupplier, $email, $notelpon, $pic, $idsupplier);
    $stmt->execute();
    $stmt->close();

    // Redirect to the same page to prevent form resubmission
    header("Location: supplier.php");
    exit();
}

// Tangani form hapus
if (isset($_POST['hapus_supplier'])) {
    $idsupplier = $_POST['idsupplier'];

    $stmt = $conn->prepare("DELETE FROM supplier WHERE idsupplier=?");
    $stmt->bind_param("i", $idsupplier);
    $stmt->execute();
    $stmt->close();

    // Redirect to the same page to prevent form resubmission
    header("Location: supplier.php");
    exit();
}

// Tangani form tambah
if (isset($_POST['tambah_supplier'])) {
    $namasupplier = $_POST['namasupplier'];
    $email = $_POST['email'];
    $notelpon = $_POST['notelpon'];
    $pic = $_POST['pic'];

    $stmt = $conn->prepare("INSERT INTO supplier (namasupplier, email, notelpon, pic) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $namasupplier, $email, $notelpon, $pic);
    $stmt->execute();
    $stmt->close();

    // Redirect to the same page to prevent form resubmission
    header("Location: supplier.php");
    exit();
}

// Tutup koneksi pada akhir script
function closeConnection($conn)
{
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <h1 class="navbar-brand ps-3" href="index.php">Inventory Management System</h1>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock
                        </a>
                        <a class="nav-link" href="masuk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock In
                        </a>
                        <a class="nav-link" href="keluar.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stock Out
                        </a>
                        <a class="nav-link" href="supplier.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Supplier
                        </a>
                        <a class="nav-link" href="ivr.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            IVR
                        </a>
                        <a class="nav-link" href="logout.php">
                            Logout
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="Big">Maintenance Team</div>
                    R-975
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Supplier Sparepart</h1>
                    <div class="card mb-4">
                        <div class="card-header">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#supplierModal">
                                Tambah Supplier
                            </button>
                            <a href="exportsupplier.php" class="btn btn-info">Export Supplier</a>
                        </div>
                        <div class="card-body">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>Supplier</th>
                                        <th>Email</th>
                                        <th>No Telpon</th>
                                        <th>Pic</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $stmt = $conn->prepare("SELECT * FROM supplier");
                                    $stmt->execute();
                                    $result = $stmt->get_result();
                                    while ($data = $result->fetch_assoc()) {
                                        $idsupplier = $data['idsupplier'];
                                        $namasupplier = $data['namasupplier'];
                                        $email = $data['email'];
                                        $notelpon = $data['notelpon'];
                                        $pic = $data['pic'];
                                    ?>
                                        <tr>
                                            <td><?= htmlspecialchars($namasupplier); ?></td>
                                            <td><?= htmlspecialchars($email); ?></td>
                                            <td><?= htmlspecialchars($notelpon); ?></td>
                                            <td><?= htmlspecialchars($pic); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $idsupplier; ?>">
                                                    Edit
                                                </button>
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete<?= $idsupplier; ?>">
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                        <!-- Edit The Modal -->
                                        <div class="modal fade" id="edit<?= $idsupplier; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Edit Supplier</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            <input type="text" name="namasupplier" value="<?= htmlspecialchars($namasupplier); ?>" class="form-control" required>
                                                            <br>
                                                            <input type="email" name="email" value="<?= htmlspecialchars($email); ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="notelpon" value="<?= htmlspecialchars($notelpon); ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="pic" value="<?= htmlspecialchars($pic); ?>" class="form-control" required>
                                                            <br>
                                                            <input type="hidden" name="idsupplier" value="<?= $idsupplier; ?>">
                                                            <button type="submit" class="btn btn-primary" name="update_supplier">Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Delete The Modal -->
                                        <div class="modal fade" id="delete<?= $idsupplier; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Hapus Supplier</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            Yakin ingin menghapus <?= htmlspecialchars($namasupplier); ?>? Pastikan sekali lagi!!
                                                            <input type="hidden" name="idsupplier" value="<?= $idsupplier; ?>">
                                                            <br>
                                                            <br>
                                                            <button type="submit" class="btn btn-danger" name="hapus_supplier">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    }
                                    $stmt->close();
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; PT.Sarimelati Kencana R-975 Factory Cikarang</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>

<!-- The Modal -->
<div class="modal fade" id="supplierModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Tambah Supplier</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <input type="text" name="namasupplier" placeholder="Nama Supplier" class="form-control" required>
                    <br>
                    <input type="email" name="email" placeholder="Email" class="form-control" required>
                    <br>
                    <input type="text" name="notelpon" placeholder="No Telpon" class="form-control" required>
                    <br>
                    <input type="text" name="pic" placeholder="PIC" class="form-control" required>
                    <br>
                    <button type="submit" class="btn btn-primary" name="tambah_supplier">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

</html>