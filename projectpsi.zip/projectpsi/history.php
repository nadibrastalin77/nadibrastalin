<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "stokbarang");

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Dapatkan part number dari input pengguna
$partnumber_input = $_GET['partnumber'] ?? '';

// Query untuk mendapatkan data stok barang berdasarkan part number
if ($partnumber_input) {
    $ambilsemuadatastock = mysqli_query($conn, "SELECT * FROM stock WHERE partnumber = '$partnumber_input'");
} else {
    $ambilsemuadatastock = mysqli_query($conn, "SELECT * FROM stock");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Stok Barang</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .header {
            text-align: center;
        }
    </style>
</head>
<body>

<h1 class="header">PT. AISAN NASMOCO INDUSTRI</h1>
<h3 class="header">KARTU STOK BARANG</h3>

<!-- Form untuk input part number -->
<form method="GET" action="">
    <label for="partnumber">Masukkan Part Number:</label><br>
    <input type="text" id="partnumber" name="partnumber" value="<?= htmlspecialchars($partnumber_input); ?>">
    <button type="submit">Cari</button>
</form>
<br>
<table id="exportstockbarangani">
    <?php
    while($data = mysqli_fetch_assoc($ambilsemuadatastock)) {
        $partnumber = $data['partnumber'];
        $namabarang = $data['namabarang'];
        $lokasibarang = $data['lokasibarang'];
        $qty_packing = $data['qty_packing'];
        $stock = $data['stock'];
        
        // Ambil data masuk
        $ambilmasuk = mysqli_query($conn, "SELECT tanggal, qty, pic 
                                           FROM masuk m, stock s 
                                           WHERE s.idbarang = m.idbarang AND s.partnumber='$partnumber'");
        $allStockIn = [];
        while ($dataMasuk = mysqli_fetch_assoc($ambilmasuk)) {
            $allStockIn[] = $dataMasuk;
        }

        // Ambil data keluar
        $ambilkeluar = mysqli_query($conn, "SELECT tanggal, qty, pic 
                                            FROM keluar k, stock s 
                                            WHERE s.idbarang = k.idbarang AND s.partnumber='$partnumber'");
        $allStockOut = [];
        while ($dataKeluar = mysqli_fetch_assoc($ambilkeluar)) {
            $allStockOut[] = $dataKeluar;
        }
    ?>
    <tr>
        <th>PART NO.</th>
        <td colspan="3"><?=$partnumber;?></td>
        <th>LOKASI</th>
        <td colspan="4"><?=$lokasibarang;?></td>
    </tr>
    <tr>
        <th>PART NAME</th>
        <td colspan="3"><?=$namabarang;?></td>
        <th>QTY. PACKING</th>
        <td colspan="4"><?=$qty_packing;?></td>
    </tr>
    <tr>
        <th>TANGGAL</th>
        <th>STOCK IN</th>
        <th>NAME</th>
        <th>TANGGAL</th>
        <th>STOCK OUT</th>
        <th>NAME</th>
    </tr>
    <?php
    $totalStockIn = 0;
    $totalStockOut = 0;
    $maxRows = max(count($allStockIn), count($allStockOut));
    for ($i = 0; $i < $maxRows; $i++) {
        $tanggalMasuk = $allStockIn[$i]['tanggal'] ?? '';
        $qtyMasuk = isset($allStockIn[$i]['qty']) ? (int)$allStockIn[$i]['qty'] : 0;
        $picMasuk = $allStockIn[$i]['pic'] ?? '';
        $totalStockIn += $qtyMasuk;

        $tanggalKeluar = $allStockOut[$i]['tanggal'] ?? '';
        $stockOut = isset($allStockOut[$i]['qty']) ? (int)$allStockOut[$i]['qty'] : 0;
        $picKeluar = $allStockOut[$i]['pic'] ?? '';
        $totalStockOut += $stockOut;
    ?>
    <tr>
        <td><?= $tanggalMasuk; ?></td>
        <td><?= $qtyMasuk; ?></td>
        <td><?= $picMasuk; ?></td>
        <td><?= $tanggalKeluar; ?></td>
        <td><?= $stockOut; ?></td>
        <td><?= $picKeluar; ?></td>
    </tr>
    <?php
    }
    $grandTotalStock = $stock;
    ?>
    <tr>
        <th colspan="6">GRAND TOTAL STOCK</th>
        <td><?=$grandTotalStock;?></td>
    </tr>
    <?php
    }
    ?>
</table>
<br>
<!-- Tombol Kembali -->
<button onclick="window.location.href = 'index.php'">Kembali</button>

<!-- Tombol Ekspor Excel -->
<button onclick="exportTableToExcel('exportstockbarangani', 'Kartu Stok Barang')">Export to Excel</button>

<!-- Tombol Ekspor PDF -->
<button onclick="exportTableToPDF('exportstockbarangani', 'Kartu Stok Barang')">Export to PDF</button>

<!-- Tombol Print -->
<button onclick="window.print()">Print</button>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
<script>
function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');

    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';

    // Create download link element
    downloadLink = document.createElement("a");

    document.body.appendChild(downloadLink);

    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;

        // Setting the file name
        downloadLink.download = filename;

        //triggering the function
        downloadLink.click();
    }
}

function exportTableToPDF(tableID, filename = ''){
    var doc = new jsPDF('p', 'pt', 'a4');
    var elem = document.getElementById(tableID);
    var html = elem.outerHTML;

    doc.html(html, {
        callback: function (doc) {
            doc.save(filename + '.pdf');
        }
    });
}
</script>
</body>
</html>
